from engine import level_manager
from engine.const import CONST
from engine.init import engine
from engine.level_manager import get_level
from engine.physics_manager import physics_manager, BodyType
from engine.stat import get_value
from engine.vector import Vector2
from event.physics_event import get_physics_event
from extensions.jump_pit.invisible_box import InvisibleBox
from game_object.game_object_main import GameObject
from game_object.rectangle import Rectangle
from game_object.text import Text
from scenes.credits import Credits
from scenes.gamestate import GameState

__author__ = 'Elias Farhan'


class StoryManager(GameObject):
    def __init__(self):
        GameObject.__init__(self)
        self.text = Text(pos=Vector2(engine.screen_size.x/2, 200),size=50,font=CONST.font,text="Things can be impossible", center=True)
        self.state = 0
    def loop(self,screen):
        physics_events = get_physics_event()
        for event in physics_events:
            #log(str(event)+" "+str(event.userDataA)+" "+str(event.userDataB)+" "+str(event.begin))

            if (event.userDataA == 1 and event.userDataB == 20) or \
                    (event.userDataB == 1 and event.userDataA == 20):
                if event.begin and self.state == 0:
                    self.text.set_text("But it's hard to go back")
                    self.state = 1
                    new_rect = InvisibleBox(direct=True)
                    new_rect.pos = Vector2(1300,500)
                    new_rect.size = Vector2(200,engine.screen_size.y)
                    new_rect.json_data = {
                        "physic_objects":{
                            "fixtures":[
                                {
                                    "user_data": 103
                                }
                            ]
                        }
                    }
                    new_rect.disappear = False
                    new_rect.body = physics_manager.add_body(new_rect.pos+new_rect.size/2, BodyType.static,)
                    physics_manager.add_box(new_rect.body,Vector2(),new_rect.size/2,user_data=103,sensor=True)
                    get_level().objects[2].append(new_rect)
            if (event.userDataA == 1 and event.userDataB == 103) or \
                    (event.userDataB == 1 and event.userDataA == 103):
                if event.begin and self.state == 1:
                    self.text.set_text("So, we go forward")
                    self.state = 2
            if (event.userDataA == 1 and event.userDataB == 21) or \
                    (event.userDataB == 1 and event.userDataA == 21):
                if event.begin and self.state == 2:
                    self.text.set_text("And if we can't, we try to go up")
                    self.state = 3
        if self.state == 3 and get_value("second").pos.y > 500:
            get_value("second").pos -= Vector2(0,1)
            physics_manager.set_body_position(get_level().player.body, physics_manager.get_body_position(get_level().player.body) - Vector2(0,1))
            physics_manager.set_body_position(get_value("second").body, get_value("second").pos+get_value("second").size/2)
        elif self.state == 3 and get_value("second").pos.y <= 500:
            self.state = 4
            self.text.set_text("Where failing is an option")
        if self.state != 4 and get_level().player.get_real_pos().y > engine.screen_size.y:
            get_level().exit()
            level_manager.switch_level(GameState(get_level().filename))
        elif self.state == 4 and get_level().player.get_real_pos().y > engine.screen_size.y:
            get_level().exit()
            level_manager.switch_level(Credits())
        self.text.loop(screen)
    @staticmethod
    def parse_image(image_data, pos, size, angle):
        return StoryManager()