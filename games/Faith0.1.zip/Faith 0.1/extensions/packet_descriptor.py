
class PacketDescriptor():
    def __init__(self, ID, type, parsedJson):
        self.id = ID
        self.type = type
        self.dict = parsedJson
