from engine.network_manager import PyNetworkManager

__author__ = 'efarhan'


class SFMLNetworkManager(PyNetworkManager):
    def __init__(self):
        pass