from game_object.game_object_main import GameObject

__author__ = 'Elias'

class GUIElement(GameObject):
    def __init__(self):
        GameObject.__init__(self)

    def loop(self,screen):
        pass

    @staticmethod
    def parse_gui(gui_data):
        return None