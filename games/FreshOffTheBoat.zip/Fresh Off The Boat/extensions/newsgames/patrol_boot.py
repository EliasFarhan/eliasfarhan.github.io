import math
from engine.const import log, CONST
from engine.img_manager import img_manager
from engine.vector import Vector2
from extensions.newsgames.refugees import Refugee
from game_object.text import Text

__author__ = 'Elias'
from animation.animation_main import Animation
from engine import level_manager
from engine.init import engine
from engine.physics_manager import physics_manager
from event.physics_event import get_physics_event
from engine.input_manager import input_manager

__author__ = 'Elias'

class BootAnimation(Animation):
    def __init__(self,player):
        Animation.__init__(self, player)
        self.foot = 0
        self.player = self.obj
        self.speed = 3
        self.h_dir, self.v_dir = True, True #True for right, True for down
        self.saved = 0

        self.place = 0
        self.place_limit = 10
        self.place_text = Text(self.player.pos+self.player.size/2-Vector2(0,-100),
                               size=20,
                               font=CONST.font,
                               text="Available places: 10")
        """self.dead_text = Text(pos=Vector2(),
                              size=50,
                              font=CONST.font,
                              text="Deaths: 0")"""
        self.victory_text = Text(pos=engine.get_screen_size()/2-Vector2(0,681)/2+Vector2(0,75),
                                 size=50,
                                 font="data/font/OldNewspaperTypes.ttf",
                                 text=" HAVE DROWNED TODAY.",
                                 center=True)
        self.restart_text = Text(pos=engine.get_screen_size()/2-Vector2(0,681)/2+Vector2(0,75)+Vector2(0,50),
                                 size=50,
                                 font="data/font/OldNewspaperTypes.ttf",
                                 text="PRESS R TO RESTART",
                                 center=True)

        self.news_img = img_manager.load_image("data/sprites/rpg_background/newspaper.png")
    def load_images(self, size=None, tmp=False):
        Animation.load_images(self, size=size, tmp=tmp)

    def update_animation(self, state="", invert=False):
        self.update_state()
        return Animation.update_animation(self, state=state, invert=invert)

    def update_state(self):
        """Main prototyping part, managing the input, hte physics events, moving the object, moving the screen_pos"""
        RIGHT = input_manager.get_button('right')
        LEFT = input_manager.get_button('left')
        UP = input_manager.get_button('up')
        DOWN = input_manager.get_button('down')
        self.state = "move"
        horizontal = RIGHT-LEFT
        vertical = UP-DOWN
        self.player.flip = False

        physics_events = get_physics_event()

        for event in physics_events:
            if (event.userDataA == 2 and 100 <= event.userDataB <= 200 ) or \
                    ( event.userDataB == 2 and 100 <= event.userDataA <= 200):
                #log(str(event.userDataA)+" "+str(event.userDataB)+" "+str(event.begin))
                if event.begin:
                    #TODO save the boat
                    if event.userDataA != 2:
                        refugee_number = event.userDataA
                    else:
                        refugee_number = event.userDataB
                    refugee_number -= 100
                    log(refugee_number)
                    for refugee in level_manager.level.objects[1]:
                        try:
                            if refugee_number == refugee.number:
                                if self.place < self.place_limit:
                                    refugee.remove = True

                                    self.place += 1
                        except AttributeError:
                            pass
            if (event.userDataA == 2 and event.userDataB == 15 ) or \
                    ( event.userDataB == 2 and event.userDataA == 15):
                if event.begin:
                    self.saved += self.place
                    self.place = 0

        if horizontal == -1:
            self.h_dir = False
            self.player.flip = False
            physics_manager.move(self.player.body, -self.speed)
        elif horizontal == 1:
            self.h_dir = True
            self.player.flip = False
            physics_manager.move(self.player.body, self.speed)
        else:
            physics_manager.move(self.player.body, 0)
        if vertical == -1:
            self.v_dir = True
            self.player.flip = False
            physics_manager.move(self.player.body, vy=self.speed)
        elif vertical == 1:
            self.v_dir = False
            self.player.flip = False
            physics_manager.move(self.player.body, vy=-self.speed)
        else:
            physics_manager.move(self.player.body, vy=0)

        if horizontal == 0:
            if vertical == 1:
                self.player.angle = 0
            elif vertical == -1:
                self.player.angle = 180
        elif vertical == 0:
            if horizontal == 1:
                self.player.angle = 90
            elif horizontal == -1:
                self.player.angle = -90
        elif horizontal == 1 and vertical == 1:
            self.player.angle = 45
        elif horizontal == 1 and vertical == -1:
            self.player.angle = 90+45
        elif horizontal == -1 and vertical == -1:
            self.player.angle = -90-45
        elif horizontal == -1 and vertical == 1:
            self.player.angle = -45
        log(self.player.angle)


        physics_pos = physics_manager.get_body_position(self.player.body)

        if physics_pos:
            pos = physics_pos-self.player.size/2
        else:
            pos = self.player.pos
        if self.player.screen_relative_pos:
            pos = pos-self.player.screen_relative_pos*engine.get_screen_size()
        self.player.pos = pos

        self.set_screen_pos()


        if Refugee.dead+self.saved != 100:

            self.place_text.pos = self.player.pos+self.player.size/2-Vector2(75,100)+self.player.screen_relative_pos*engine.get_screen_size()
            self.place_text.set_text("Available places: "+str(self.place_limit-self.place))
            self.place_text.loop(engine.screen)
            """self.dead_text.set_text("Deaths: "+str(Refugee.dead))
            self.dead_text.loop(engine.screen)"""

        else:
            img_manager.show_image(self.news_img, engine.screen,engine.get_screen_size()/2-Vector2(1041,681)/2,new_size=Vector2(1041,681))
            self.victory_text.set_text(str(Refugee.dead)+" REFUGEES HAVE DROWNED TODAY.")
            self.victory_text.loop(engine.screen)
            self.restart_text.loop(engine.screen)
            self.player.pos = Vector2(-2000,-2000)

    def set_screen_pos(self):
        #level_manager.level.screen_pos = self.player.pos
        pass
    @staticmethod
    def parse_special_animation(anim, anim_data):
        pass