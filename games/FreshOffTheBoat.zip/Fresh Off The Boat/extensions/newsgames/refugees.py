import random
from time import time
import math
from animation.animation_main import Animation
from engine import level_manager
from engine.const import log
from engine.img_manager import img_manager
from engine.physics_manager import physics_manager, BodyType
from engine.rect import Rect
from engine.snd_manager import snd_manager
from engine.vector import Vector2
from game_object.game_object_main import GameObject
from game_object.image import Image

__author__ = 'Elias'


class Refugee(Image):
    i = 0
    dead = 0
    def __init__(self,pos,size):
        self.number = Refugee.i
        Image.__init__(self,pos,size)
        self.body = physics_manager.add_body(self.pos+self.size/2,
                                             body_type=BodyType.static)
        physics_manager.add_box(self.body,Vector2(),size=self.size/8,user_data=100+Refugee.i,sensor=True)
        Refugee.i+=1
        self.timer = random.random()*60
        log(self.timer)
        self.born_time = time()
        self.drowning_sound = random.choice([
            snd_manager.load_sound("data/sound/drowning.ogg"),
            snd_manager.load_sound("data/sound/drowning2.ogg"),
            snd_manager.load_sound("data/sound/drowning3.ogg")
        ])
        self.playgin_sound = False
        self.anim = Animation(self)
        self.anim.state_range = {"idle": [0,6]}
        self.anim.state = "idle"
        self.anim.root_path = "data/sprites/drowning/"
        self.anim.path_list = [""]
        self.anim.load_images()
        self.anim.img = self.anim.img_indexes[random.randint(0,5)]
    def loop(self, screen):
        Image.loop(self,screen)
        #img_manager.draw_rect(screen,Rect(self.pos,self.size), color=[255,0,0,125])
        #log(time()-self.born_time)
        if time()-self.born_time > self.timer - 1 and not self.playgin_sound:
            snd_manager.play_sound(self.drowning_sound)
            self.playgin_sound = True

        if time()-self.born_time > self.timer and not self.remove:
            self.remove = True
            Refugee.dead += 1
class Refugees(GameObject):
    def __init__(self):
        snd_manager.set_playlist(["data/sound/edited_background.ogg"])
        GameObject.__init__(self)
        Refugee.i = 0
        Refugee.dead = 0
        self.refugee_size = Vector2(100,100)

        self.refugee_number = 100

        for i in range(0,self.refugee_number):
            x = 0
            for j in range(0,2):
                x += random.randint(0,50)
            x = x /100.0
            y = 0
            for j in range(0,2):
                y+= random.randint(0,50)
            y -= 50
            y = math.fabs(y)
            y = y/50.0
            level_manager.level.objects[1].append(Refugee(pos=Vector2(1820*x, 800*y),size=self.refugee_size))

    @staticmethod
    def parse_image(image_data, pos, size, angle):
        return Refugees()