from engine.img_manager import img_manager
from engine.rect import Rect
from engine.vector import Vector2
from game_object.game_object_main import GameObject
from json_export.json_main import get_element

__author__ = 'Elias Farhan'


class Rectangle(GameObject):
    
    def loop(self,screen):
        GameObject.loop(self,screen)
        if self.pos and self.size:
            img_manager.draw_rect(screen,Rect(self.pos, self.size),color=self.color,angle=self.angle)
    @staticmethod
    def parse_image(image_data, pos, size, angle):
        rect = Rectangle()
        rect.pos = Vector2(pos)
        rect.size = Vector2(size)
        rect.angle = angle
        color = get_element(image_data, "color")
        if color is None:
            color = (255,0,0,255)
        rect.color = color
        return rect