from engine import level_manager
from engine.input_manager import input_manager
from engine.const import log
from engine.level_manager import get_level
from engine.physics_manager import physics_manager
from engine.init import engine
from engine.rect import Rect
from engine.img_manager import img_manager
from engine.vector import Vector2
from event.physics_event import get_physics_event
from game_object.game_object_main import GameObject
from scenes.gamestate import GameState

__author__ = 'Elias'


class JumpPlayer(GameObject):

    def __init__(self):
        GameObject.__init__(self)
        self.foot = False
        self.player = self
        self.speed = 10
        self.jump = 10
        self.direction = True #True for right
        self.jump_clicked = False

    def loop(self,screen):
        RIGHT = input_manager.get_button('right')
        LEFT = input_manager.get_button('left')
        UP = input_manager.get_button('up')or input_manager.get_button("jump")
        DOWN = input_manager.get_button('down')

        horizontal = RIGHT-LEFT
        vertical = UP-DOWN

        physics_events = get_physics_event()

        #log("Before: "+str(self.foot))
        for event in physics_events:
            log(str(event)+" "+str(event.userDataA)+" "+str(event.userDataB)+" "+str(event.begin))

            if (event.userDataA == 1 and event.userDataB == 11) or \
                    (event.userDataB == 1 and event.userDataA == 11):
                if event.begin:
                    self.foot += 1
                else:
                    self.foot -= 1
        #log("After: "+str(self.foot))
        if horizontal == -1:
            self.direction = False
            if self.foot:
                self.state = 'move'
            self.player.flip = True
            physics_manager.move(self.player.body, vx=-self.speed)
        elif horizontal == 1:
            self.direction = True
            if self.foot:
                self.state = 'move'
            self.player.flip = False
            physics_manager.move(self.player.body, vx=self.speed)

        else:
            if self.foot:
                if self.direction:
                    self.state = 'still'
                    self.player.flip = False
                else:
                    self.state = 'still'
                    self.player.flip = True
            physics_manager.move(self.player.body, vx=0)

        if vertical == 1:
            if self.foot and not self.jump_clicked:
                self.jump_clicked = True
                physics_manager.jump(self.player.body, vy=self.jump)
        else:
            self.jump_clicked = False
        if not self.foot:

            if self.direction:
                self.state = 'jump'
                self.player.flip = False
            else:
                self.state = 'jump'
                self.player.flip = True

        if self.body:
            physics_pos = physics_manager.get_body_position(self.body)
            if physics_pos:
                pos = physics_pos-self.size/2
            else:
                pos = self.pos

            if self.screen_relative_pos:
                pos = pos-self.screen_relative_pos*engine.get_screen_size()
            self.pos = pos
        img_manager.draw_circle(screen, pos=self.pos+self.screen_relative_pos*engine.screen_size, radius=self.size.x/2,color=(0,255,0))
        #log(self.player.foot)

    def get_real_pos(self):
        return self.pos+self.screen_relative_pos*engine.screen_size
    @staticmethod
    def parse_image(json_data, pos, size, angle):
        player = JumpPlayer()

        if not isinstance(pos, Vector2):
            if isinstance(pos[0], list) or isinstance(pos[0], tuple):
                player.pos = Vector2(pos[0])
                player.screen_relative_pos = Vector2(pos[1])
            else:
                player.pos = Vector2(pos)
        else:
            player.pos = pos
        player.size = Vector2(size)
        return player