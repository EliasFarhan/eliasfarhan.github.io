from engine.const import log
from engine.img_manager import img_manager
from engine.init import engine
from engine.level_manager import get_level
from engine.physics_manager import physics_manager, BodyType
from engine.rect import Rect
from engine.vector import Vector2
from event.physics_event import get_physics_event
from game_object.game_object_main import GameObject
from json_export.json_main import get_element

__author__ = 'Elias'

class InvisibleBox(GameObject):
    def __init__(self, direct=False):
        GameObject.__init__(self)
        self.visible = False
        self.solid_body = None
        self.direct = direct
        self.num = 0
        self.disappear = True
    def loop(self, screen):
        GameObject.loop(self,screen)
        if self.num == 0:
            physics_objects = get_element(self.json_data, "physic_objects")
            if physics_objects is not None:
                fixtures = get_element(physics_objects, "fixtures")
                log(str(len(fixtures)))
                if fixtures is not None and len(fixtures) != 0:
                    self.num = get_element(fixtures[0], "user_data")
        begin_contact = None
        physics_events = get_physics_event()
        for event in physics_events:
            log(str(event)+" "+str(event.userDataA)+" "+str(event.userDataB)+" "+str(event.begin)+" "+str(self.num))
            if event.userDataA == 1 and event.userDataB == self.num:
                begin_contact = event.begin
            elif event.userDataB == 1 and event.userDataA == self.num:
                begin_contact = event.begin

        if begin_contact is not None:

            log("Collision with "+str(self.num)+" Begin: "+str(begin_contact))
            if begin_contact and (get_level().player.foot or self.direct) and self.solid_body is None:
                self.visible = True
                self.solid_body = physics_manager.add_body(self.pos+self.size/2, BodyType.static, 0)
                physics_manager.add_box(self.solid_body, Vector2(), Vector2(self.size/2), 0, user_data=12, sensor=False)
                if self.disappear:
                    get_level().player.foot += 1

            elif not begin_contact:
                log("Trying to removing body "+str(physics_manager))
                self.visible = False
                if self.solid_body is not None:
                    log("Removing body "+str(physics_manager))
                    physics_manager.remove_body(self.solid_body)
                    self.solid_body = None
                    if self.disappear:
                        get_level().player.foot -= 1
        if self.pos and self.size and self.visible:
            img_manager.draw_rect(screen,Rect(self.pos, self.size),color=(255,0,0,150))
    @staticmethod
    def parse_image(image_data, pos, size, angle):
        box = InvisibleBox()
        box.pos = Vector2(pos)
        box.size = Vector2(size)
        box.disappear = get_element(image_data, "disappear")
        if box.disappear is None:
            box.disappear = True
        return box