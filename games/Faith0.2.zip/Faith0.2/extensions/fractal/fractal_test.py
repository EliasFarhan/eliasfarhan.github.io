from engine.const import log
from engine.img_manager import img_manager
from engine.init import engine
from engine.vector import Vector2
from game_object.game_object_main import GameObject
import sfml
import time
__author__ = 'Elias'


class FractalTest(GameObject):
    def __init__(self):
        GameObject.__init__(self)
        self.size = Vector2(500,500)
        self.rectangle = sfml.RectangleShape()
        self.rectangle.fill_color = sfml.Color.WHITE
        #self.palette_tex = sfml.Texture.from_file("data/shader/pal.png")
        self.shader = sfml.Shader.from_file("data/shader/mandelbrot.vert","data/shader/mandelbrot.frag")
        self.scale = 1.0
        self.shader.set_parameter("real", -1.0)

        self.shader.set_parameter("imag", -1.0)
        self.w = 1.0
        self.h = 1.0
        self.shader.set_parameter("w", self.w)
        self.shader.set_parameter("h", self.h)
        #self.shader.set_4float_parameter("position", 0.0,0.0,0.0,1.0)
        self.start_time = time.time()
        #self.shader.set_texture_parameter("tex", self.palette_tex)

    def loop(self,screen):
        #self.scale -= 0.0001
        #self.center.x += 0.01
        #self.center.y += 0.


        self.rectangle.size = (self.size*engine.get_ratio()).get_list()
        self.rectangle.position = (self.pos+engine.get_origin_pos()).get_list()
        #self.shader.set_parameter("time", (time.time()-self.start_time)/5000.0)

        states = sfml.RenderStates()
        states.shader = self.shader
        screen.draw(self.rectangle, states)

    @staticmethod
    def parse_image(image_data, pos, size, angle=0):
        return FractalTest()