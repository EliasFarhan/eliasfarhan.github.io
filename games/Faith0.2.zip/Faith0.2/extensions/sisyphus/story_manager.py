import random
from engine import level_manager, stat
from engine.const import log, CONST
from engine.init import engine
from engine.vector import Vector2
from game_object.game_object_main import GameObject
from game_object.text import Text
from scenes.gamestate import GameState

__author__ = 'Elias Farhan'


quote_filename = "data/json/sisyphus/quotes.txt"
quote_file = open(quote_filename, 'r')
quotes_list = []
for line in quote_file:
    quotes_list.append(line)
log(quotes_list)


class StoryManager(GameObject):
    def __init__(self):
        GameObject.__init__(self)
        self.quotes_text = []


        self.index = stat.get_value("index")
        if self.index is None:
            self.index = 0
        self.reload()

        stat.set_value("end_reach", False)
    def reload(self, error=False):
        global quotes_list
        del self.quotes_text[:]
        text_length = 40
        if error:
            text = "Move the damn rock!"
        elif self.index == 0:
            text = "You have one task, Sisyphus. Bring the rock to the top!"
        elif self.index == 2:
            text = "You may always go back, but then you will never see the end"
        elif self.index == 5:
            text = "You may ask, what is the purpose of it?"
        elif self.index == 8:
            text = "Is there an end to it?"
        elif self.index == 11:
            text = "Still 10 steps to go, maybe..."
        elif self.index == 16:
            text = "Still 5"
        elif self.index == 19:
            text = "2 to go"
        elif self.index == 20:
            text = "last"
        elif self.index == 21:
            text = "I'm so deeply sorry, this is not the end"
        elif self.index == 22:
            text = "Do you want yet another inspirationnal quote?"
        elif self.index == 24:
            text = "I guess your princess is in another castle"
        elif self.index == 26:
            text = "Is the end so important to you?"
        elif self.index == 28:
            text = "Don't you want to live in the moment?"
        elif self.index == 30:
            text = "Ok! You're the one who will save the world."
        elif self.index == 32:
            text = "I know it's hard to conceive it."
        elif self.index == 34:
            text = "I mean, you are the one who is moving the rock."
        elif self.index == 36:
            text = "What? You don't believe me?"
        elif self.index == 38:
            text = "How would I lie to you?"
        elif self.index == 40:
            text = "You really want the end?"
        elif self.index == 42:
            text = "Let me think..."
        elif self.index == 43:
            text = "..."
        elif self.index == 44:
            text = ".."
        elif self.index == 45:
            text = "."
        elif self.index == 46:
            text = ""
        elif self.index == 47:
            text = ""
        elif self.index == 48:
            text = "It was all but a dream!"
        elif self.index == 49:
            text = "Ok! I tried something!"
        elif self.index == 50:
            text = "Actually..."
        elif self.index == 52:
            text = "I'm your father!"
        elif self.index == 54:
            text = "No?"
        elif self.index == 56:
            text = "Are you that sure?"
        elif self.index == 58:
            text = "Don't you remember? When I was holding you in my arms?"
        elif self.index == 60:
            text = "It was not a dream, you know!"
        elif self.index == 62:
            text = "Don't go back!"
        elif self.index == 64:
            text = "As your father, I forbid you!"
        elif self.index == 66:
            text = "You have no idea how you missed me all this time"
        elif self.index == 68:
            text = "I have to go!"
        elif self.index == 69:
            text = "I'm so sorry..."
        elif self.index == 70:
            text = "Please go on for me!"
        elif self.index == 71:
            text = "Never go back!"
        elif 72 <= self.index <= 75:
            text = ""
        elif self.index == 76:
            text = "Still 5 to go to the end"
        elif self.index == 77:
            text = "4! Trust me!"
        elif self.index == 78:
            text = "3, so close!"
        elif self.index == 79:
            text = "2, come on! Don't go back now!"
        elif self.index == 80:
            text = "1, last one!"
        elif self.index == 81:
            text = "The End!"
        elif self.index == 82:
            stat.set_value("end_reach", True)
            level_manager.level.exit()
            level_manager.switch_level(GameState("data/json/sisyphus/falling_choice.json"))
            return
        else:
            text = random.choice(quotes_list)
        log(self.index)
        if not error:
            self.index += 1
        stat.set_value("index", self.index)
        quotes_string = []
        for i in range(len(text)/text_length):
            new_string = text[i*text_length:(i+1)*text_length]

            if( (i+1)*text_length!=len(text)):
                around_char = [text[(i+1)*text_length-1], text[(i+1)*text_length]]
                underscore = True
                for c in around_char:
                    if not c.isalpha() and not c.isdigit():
                        underscore = False
                        break
                if underscore:
                    new_string+="-"
            quotes_string.append(new_string)
        quotes_string.append(text[len(text)/text_length*text_length:len(text)])

        for i, new_string in enumerate(quotes_string):
            self.quotes_text.append(
                Text(
                    pos=Vector2(engine.screen_size.x/4, 100+100*i),
                    size=100,
                    font=CONST.font,
                    text=new_string,
                    center=False
                )
            )
    def loop(self,screen):
        for text in self.quotes_text:
            text.loop(screen)
    @staticmethod
    def parse_image(image_data, pos, size, angle):
        return StoryManager()