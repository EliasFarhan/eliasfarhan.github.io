import math
from engine import stat
from engine.const import log
from engine.init import engine
from engine.physics_manager import physics_manager
from engine.vector import Vector2
from game_object.rectangle import Rectangle
from json_export.json_main import get_element

__author__ = 'Elias Farhan'

class Rock(Rectangle):
    def __init__(self):
        Rectangle.__init__(self)
        self.player_contact = 0
        stat.set_value("switch", False)

    def loop(self, screen):
        #log(self.pos)
        if self.body:
            self.angle = self.body.angle/math.pi*180.0
        self.pos = physics_manager.get_body_position(self.body)-self.size/2
        if self.pos.x >= engine.screen_size.x + 100:
            self.pos = Vector2(-self.size.x,engine.screen_size.y)
            physics_manager.set_body_position(self.body,self.pos)
            stat.get_value("story").reload()
            stat.set_value("switch", True)
        if self.size.x >= self.pos.x >= 0:
            stat.set_value("switch", False)
        Rectangle.loop(self, screen)

    @staticmethod
    def parse_image(image_data, pos, size, angle):
        rect = Rock()
        rect.pos = Vector2(pos)
        rect.size = Vector2(size)
        rect.angle = angle
        color = get_element(image_data, "color")
        if color is None:
            color = (255,0,0,255)
        rect.color = color
        return rect
